#ifndef _2021013445_06_02_SCORE_H_
#define _2021013445_06_02_SCORE_H_
int GetMaxScore(int h, int w[], int s[], int CourseCount);
extern int s[11];
extern int w[11];
#endif