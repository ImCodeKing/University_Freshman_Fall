#ifndef _2021013445_06_03_SPLIT_H_
#define _2021013445_06_03_SPLIT_H_
void Split(char input[]);
#endif