#include <stdio.h>
#include "2021013445_06_03_Split.h"
int main(int argc, char* argv[])
{
	int count = 0;
	char string[10001];
	scanf("%s", &string);
	Split(string);
	return 0;
}