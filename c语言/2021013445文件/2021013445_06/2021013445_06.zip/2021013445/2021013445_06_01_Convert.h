#ifndef _2021013445_06_01_CONVERT_H_
#define _2021013445_06_01_CONVERT_H_
void Convert10to2(unsigned int n);
void Convert10to8(unsigned int n);
void Convert10to16(unsigned int n);
#endif
